
import Cocoa

//Variables and constant for the egg timer
let start = 0
var End = 180

//the skeleton
if End>start {
    for start in 1...180 {//tried to switch the 1 and 180 but didnt work out
        print("\(start) seconds left before 3 minutes")
    }
}
//end result vvv

