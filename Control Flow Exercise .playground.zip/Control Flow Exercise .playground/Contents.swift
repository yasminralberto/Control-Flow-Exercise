import Cocoa

//currently i have made a whole entire code differently instead of this sinc emy other one gotten corrupted dont know the reason for the issue but hopefully this works as well dont know if im missing something or have error. please notify me of anything or improvements

//Variables and constants

var start = 0
var End = 180

//The Skeleton

for start in 1...180 {
    print("\(start) seconds left before 3 minutes have passed")
}

